import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { GalleryComponent } from './components/gallery/gallery.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { JoinusComponent } from './components/joinus/joinus.component';
import { AdminComponent } from './components/admin/admin.component';
import { SignupComponent } from './components/signup/signup.component';

const routes: Routes = [
  {
    path:'home',
    component:HomeComponent
    
  },
  {
    path:'gallery',
    component:GalleryComponent,
    // children:[
    //   {path: 'wedding',component:WeddingComponent},
    //   {path:'events',component:EventsComponent},
    //   {path:'baby-kids',component:BabyKidsComponent},
    //   {path:'fashion',component:FashionComponent},
    //   {path:'prewedding',component:PreweddingComponent},
    //   {path:'travel',component:TravelComponent},
    //   {path:'commercial',component:CommercialComponent}
    // ]
  },
  {
    path:'about',
    component:AboutComponent
  },
  {
    path:'contact',
    component:ContactComponent
  },
  {
    path:'joinus',
    component:JoinusComponent
  },
  {
    path:'admin',
    component:AdminComponent
  },
  {
    path:'',
    component:SignupComponent
  }
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
