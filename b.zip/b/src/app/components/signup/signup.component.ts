import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  model: any = {};

  constructor(private router: Router, private cookie:CookieService) { }

  ngOnInit() {
  }

  login(){
    if(this.model.username === 'admin' && this.model.password === 'admin'){
      //alert("hi boss");
      this.router.navigate(['/joinus']);
    }
    
    else if(this.model.username === 'Arun' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    
    else if(this.model.username === 'Bharath' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    
    else if(this.model.username === 'Charan' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Darshan' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Eshawar' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Fayaz' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Gagan' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Harish' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Ifran' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
    else if(this.model.username === 'Jaanu' && this.model.password === 'admin'){
      this.router.navigate(['/joinus']);
    }
     else {
      //show your error message
    }

  }

 

}