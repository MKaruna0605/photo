import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-joinus',
  templateUrl: './joinus.component.html',
  styleUrls: ['./joinus.component.css']
})
export class JoinusComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
